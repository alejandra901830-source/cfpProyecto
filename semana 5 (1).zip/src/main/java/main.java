import java.io.IOException;
import java.io.PrintWriter;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Procesa la informacion generada por GenerateInfoFiles y crea
 * los reportes solicitados para el proyecto.
 *
 * @author Equipo de trabajo
 * @version 2.0
 */
public class main {

    /**
     * Punto de entrada del programa.
     *
     * @param args argumentos de la linea de comandos
     */
    public static void main(String[] args) {
        try {
            System.out.println("Iniciando procesamiento de datos...");

            Map<String, Producto> mapaProductos = cargarDatos(
                    "productos.csv",
                    linea -> {
                        String[] datos = linea.split(";");
                        if (datos.length != 3) {
                            throw new IllegalArgumentException(
                                    "Formato incorrecto en productos.csv: " + linea);
                        }
                        return new Producto(
                                datos[0],
                                datos[1],
                                Double.parseDouble(datos[2]));
                    },
                    Producto::getId);

            Map<String, Vendedor> mapaVendedores = cargarDatos(
                    "vendedores.csv",
                    linea -> {
                        String[] datos = linea.split(";");
                        if (datos.length != 4) {
                            throw new IllegalArgumentException(
                                    "Formato incorrecto en vendedores.csv: " + linea);
                        }
                        return new Vendedor(
                                datos[0],
                                datos[1],
                                datos[2],
                                datos[3]);
                    },
                    Vendedor::getNumDoc);

            try (Stream<Path> archivos = Files.walk(Paths.get("."))) {
                archivos
                    .filter(path -> Files.isRegularFile(path))
                    .filter(path -> path.getFileName().toString().startsWith("vendedor_"))
                    .filter(path -> path.getFileName().toString().endsWith(".csv"))
                    .forEach(path -> procesarArchivoVenta(
                            path, mapaProductos, mapaVendedores));
            }

            generarReportes(mapaVendedores, mapaProductos);

            System.out.println("¡Reportes generados correctamente!");

        } catch (Exception e) {
            System.err.println("ERROR: " + e.getMessage());
        }
    }

    /**
     * Carga registros separados por punto y coma en un mapa.
     *
     * @param archivo nombre del archivo
     * @param constructor funcion que convierte una linea en un objeto
     * @param getKey funcion que obtiene la clave del objeto
     * @param <T> tipo de objeto almacenado
     * @return mapa con los datos cargados
     * @throws IOException si ocurre un error de lectura
     */
    private static <T> Map<String, T> cargarDatos(
            String archivo,
            Function<String, T> constructor,
            Function<T, String> getKey) throws IOException {

        return Files.lines(Paths.get(archivo))
                .filter(linea -> !linea.trim().isEmpty())
                .map(constructor)
                .collect(Collectors.toMap(getKey, item -> item));
    }

    /**
     * Procesa un archivo individual de ventas.
     *
     * @param archivo archivo del vendedor
     * @param productos productos disponibles
     * @param vendedores vendedores disponibles
     */
    private static void procesarArchivoVenta(
            Path archivo,
            Map<String, Producto> productos,
            Map<String, Vendedor> vendedores) {

        try {
            List<String> lineas = Files.readAllLines(archivo);

            if (lineas.isEmpty()) {
                return;
            }

            String[] encabezado = lineas.get(0).split(";");
            if (encabezado.length != 2) {
                System.err.println("ADVERTENCIA: formato incorrecto en "
                        + archivo.getFileName());
                return;
            }

            String idVendedor = encabezado[1];
            Vendedor vendedor = vendedores.get(idVendedor);

            if (vendedor == null) {
                System.err.println("ADVERTENCIA: vendedor no encontrado para "
                        + archivo.getFileName());
                return;
            }

            for (int i = 1; i < lineas.size(); i++) {
                if (lineas.get(i).trim().isEmpty()) {
                    continue;
                }

                String[] datos = lineas.get(i).split(";");
                if (datos.length < 2) {
                    System.err.println("ADVERTENCIA: venta invalida en "
                            + archivo.getFileName());
                    continue;
                }

                Producto producto = productos.get(datos[0]);
                int cantidad = Integer.parseInt(datos[1]);

                if (cantidad < 0) {
                    System.err.println("ADVERTENCIA: cantidad negativa en "
                            + archivo.getFileName());
                    continue;
                }

                if (producto != null) {
                    vendedor.ventasTotales += producto.precio * cantidad;
                    producto.cantidadVendida += cantidad;
                } else {
                    System.err.println("ADVERTENCIA: producto "
                            + datos[0] + " no existe.");
                }
            }

        } catch (Exception e) {
            System.err.println("ADVERTENCIA: no se pudo procesar "
                    + archivo.getFileName() + " - " + e.getMessage());
        }
    }

    /**
     * Genera los dos archivos CSV solicitados.
     *
     * @param mapaVendedores vendedores procesados
     * @param mapaProductos productos procesados
     * @throws IOException si ocurre un error de escritura
     */
    private static void generarReportes(
            Map<String, Vendedor> mapaVendedores,
            Map<String, Producto> mapaProductos) throws IOException {

        List<Vendedor> vendedoresOrdenados =
                new ArrayList<Vendedor>(mapaVendedores.values());

        vendedoresOrdenados.sort(
                Comparator.comparingDouble(
                        Vendedor::getVentasTotales).reversed());

        try (PrintWriter writer = new PrintWriter("reporte_vendedores.csv")) {
            for (Vendedor vendedor : vendedoresOrdenados) {
                writer.printf(
                        "%s %s;%.2f%n",
                        vendedor.nombres,
                        vendedor.apellidos,
                        vendedor.ventasTotales);
            }
        }

        List<Producto> productosOrdenados =
                new ArrayList<Producto>(mapaProductos.values());

        productosOrdenados.sort(
                Comparator.comparingInt(
                        Producto::getCantidadVendida).reversed());

        try (PrintWriter writer = new PrintWriter("reporte_productos.csv")) {
            for (Producto producto : productosOrdenados) {
                writer.printf(
                        "%s;%.2f%n",
                        producto.nombre,
                        producto.precio);
            }
        }
    }

    /** Representa un producto. */
    private static class Producto {
        private final String id;
        private final String nombre;
        private final double precio;
        private int cantidadVendida;

        Producto(String id, String nombre, double precio) {
            this.id = id;
            this.nombre = nombre;
            this.precio = precio;
        }

        String getId() {
            return id;
        }

        int getCantidadVendida() {
            return cantidadVendida;
        }
    }

    /** Representa un vendedor. */
    private static class Vendedor {
        private final String tipoDoc;
        private final String numDoc;
        private final String nombres;
        private final String apellidos;
        private double ventasTotales;

        Vendedor(String tipoDoc, String numDoc, String nombres, String apellidos) {
            this.tipoDoc = tipoDoc;
            this.numDoc = numDoc;
            this.nombres = nombres;
            this.apellidos = apellidos;
        }

        String getNumDoc() {
            return numDoc;
        }

        double getVentasTotales() {
            return ventasTotales;
        }
    }
}
