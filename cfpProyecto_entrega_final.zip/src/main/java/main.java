import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;
import java.util.stream.Stream;

/**
 * Lee los archivos de entrada y genera los reportes de recaudación por
 * vendedor y de productos vendidos, sin solicitar datos al usuario.
 *
 * @author Equipo de trabajo
 * @version 1.0
 */
public class main {

    private static final String ARCHIVO_PRODUCTOS = "productos.csv";
    private static final String ARCHIVO_VENDEDORES = "vendedores.csv";
    private static final String REPORTE_VENDEDORES = "reporte_vendedores.csv";
    private static final String REPORTE_PRODUCTOS = "reporte_productos.csv";

    /**
     * Ejecuta el procesamiento y genera los dos reportes requeridos.
     *
     * @param args argumentos de consola (no utilizados)
     */
    public static void main(String[] args) {
        try {
            Map<String, Producto> productos = cargarProductos();
            Map<String, Vendedor> vendedores = cargarVendedores();
            procesarArchivosDeVentas(productos, vendedores);
            generarReporteVendedores(vendedores);
            generarReporteProductos(productos);
            System.out.println("Procesamiento finalizado exitosamente. Reportes creados: "
                    + REPORTE_VENDEDORES + " y " + REPORTE_PRODUCTOS + ".");
        } catch (Exception exception) {
            System.err.println("ERROR al procesar el proyecto: " + exception.getMessage());
        }
    }

    /** @return catálogo de productos indexado por identificador */
    private static Map<String, Producto> cargarProductos() throws IOException {
        Map<String, Producto> productos = new HashMap<String, Producto>();
        List<String> lineas = Files.readAllLines(Paths.get(ARCHIVO_PRODUCTOS), StandardCharsets.UTF_8);
        for (String linea : lineas) {
            if (linea.trim().isEmpty()) {
                continue;
            }
            String[] campos = linea.split(";", -1);
            if (campos.length != 3 || campos[0].trim().isEmpty()
                    || campos[1].trim().isEmpty()) {
                throw new IllegalArgumentException("Registro inválido en " + ARCHIVO_PRODUCTOS
                        + ": " + linea);
            }
            double precio = Double.parseDouble(campos[2].trim());
            if (precio < 0 || Double.isNaN(precio) || Double.isInfinite(precio)) {
                throw new IllegalArgumentException("Precio inválido en " + ARCHIVO_PRODUCTOS
                        + ": " + linea);
            }
            Producto producto = new Producto(campos[0].trim(), campos[1].trim(), precio);
            if (productos.put(producto.id, producto) != null) {
                throw new IllegalArgumentException("ID de producto duplicado: " + producto.id);
            }
        }
        if (productos.isEmpty()) {
            throw new IllegalArgumentException("El catálogo de productos está vacío.");
        }
        return productos;
    }

    /** @return vendedores indexados por número de documento */
    private static Map<String, Vendedor> cargarVendedores() throws IOException {
        Map<String, Vendedor> vendedores = new HashMap<String, Vendedor>();
        List<String> lineas = Files.readAllLines(Paths.get(ARCHIVO_VENDEDORES), StandardCharsets.UTF_8);
        for (String linea : lineas) {
            if (linea.trim().isEmpty()) {
                continue;
            }
            String[] campos = linea.split(";", -1);
            if (campos.length != 4) {
                throw new IllegalArgumentException("Registro inválido en " + ARCHIVO_VENDEDORES
                        + ": " + linea);
            }
            Vendedor vendedor = new Vendedor(
                    campos[0].trim(), campos[1].trim(), campos[2].trim(), campos[3].trim());
            if (vendedores.put(vendedor.numeroDocumento, vendedor) != null) {
                throw new IllegalArgumentException("Documento de vendedor duplicado: "
                        + vendedor.numeroDocumento);
            }
        }
        if (vendedores.isEmpty()) {
            throw new IllegalArgumentException("El archivo de vendedores está vacío.");
        }
        return vendedores;
    }

    /**
     * Procesa todos los archivos vendedor_<documento>.csv ubicados en la carpeta
     * del proyecto. El encabezado de cada archivo contiene tipo de documento e ID.
     */
    private static void procesarArchivosDeVentas(
            Map<String, Producto> productos, Map<String, Vendedor> vendedores) throws IOException {
        try (Stream<Path> archivos = Files.list(Paths.get("."))) {
            List<Path> archivosVentas = archivos
                    .filter(Files::isRegularFile)
                    .filter(path -> path.getFileName().toString().startsWith("vendedor_"))
                    .filter(path -> path.getFileName().toString().endsWith(".csv"))
                    .sorted()
                    .collect(Collectors.toList());

            if (archivosVentas.isEmpty()) {
                throw new IllegalArgumentException("No se encontraron archivos vendedor_<id>.csv.");
            }
            for (Path archivo : archivosVentas) {
                procesarArchivoVenta(archivo, productos, vendedores);
            }
        }
    }

    /** Procesa cada línea de ventas de un archivo individual. */
    private static void procesarArchivoVenta(
            Path archivo, Map<String, Producto> productos, Map<String, Vendedor> vendedores)
            throws IOException {
        List<String> lineas = Files.readAllLines(archivo, StandardCharsets.UTF_8);
        if (lineas.isEmpty()) {
            throw new IllegalArgumentException("Archivo de ventas vacío: " + archivo);
        }

        String[] encabezado = lineas.get(0).split(";", -1);
        if (encabezado.length != 2) {
            throw new IllegalArgumentException("Encabezado inválido en " + archivo);
        }
        String numeroDocumento = encabezado[1].trim();
        Vendedor vendedor = vendedores.get(numeroDocumento);
        if (vendedor == null) {
            throw new IllegalArgumentException("El vendedor " + numeroDocumento
                    + " no está registrado (archivo " + archivo + ").");
        }

        for (int index = 1; index < lineas.size(); index++) {
            String linea = lineas.get(index).trim();
            if (linea.isEmpty()) {
                continue;
            }
            String[] campos = linea.split(";", -1);
            if (campos.length < 2) {
                throw new IllegalArgumentException("Venta inválida en " + archivo + ": " + linea);
            }

            Producto producto = productos.get(campos[0].trim());
            if (producto == null) {
                throw new IllegalArgumentException("ID de producto inexistente en " + archivo
                        + ": " + campos[0]);
            }
            int cantidad = Integer.parseInt(campos[1].trim());
            if (cantidad < 0) {
                throw new IllegalArgumentException("Cantidad negativa en " + archivo + ": " + linea);
            }
            vendedor.dineroRecaudado += producto.precio * cantidad;
            producto.cantidadVendida += cantidad;
        }
    }

    /** Escribe vendedores ordenados por dinero recaudado, de mayor a menor. */
    private static void generarReporteVendedores(Map<String, Vendedor> vendedores)
            throws IOException {
        List<Vendedor> ordenados = new ArrayList<Vendedor>(vendedores.values());
        ordenados.sort(Comparator.comparingDouble(Vendedor::getDineroRecaudado).reversed());

        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(
                Paths.get(REPORTE_VENDEDORES), StandardCharsets.UTF_8))) {
            for (Vendedor vendedor : ordenados) {
                writer.printf(Locale.US, "%s %s;%.2f%n",
                        vendedor.nombres, vendedor.apellidos, vendedor.dineroRecaudado);
            }
        }
    }

    /** Escribe productos ordenados por cantidad vendida, de mayor a menor. */
    private static void generarReporteProductos(Map<String, Producto> productos)
            throws IOException {
        List<Producto> ordenados = new ArrayList<Producto>(productos.values());
        ordenados.sort(Comparator.comparingInt(Producto::getCantidadVendida).reversed());

        try (PrintWriter writer = new PrintWriter(Files.newBufferedWriter(
                Paths.get(REPORTE_PRODUCTOS), StandardCharsets.UTF_8))) {
            for (Producto producto : ordenados) {
                writer.printf(Locale.US, "%s;%.2f%n", producto.nombre, producto.precio);
            }
        }
    }

    /** Modelo de producto del catálogo. */
    private static final class Producto {
        private final String id;
        private final String nombre;
        private final double precio;
        private int cantidadVendida;

        private Producto(String id, String nombre, double precio) {
            this.id = id;
            this.nombre = nombre;
            this.precio = precio;
        }

        private int getCantidadVendida() {
            return cantidadVendida;
        }
    }

    /** Modelo de vendedor y total de recaudación acumulado. */
    private static final class Vendedor {
        private final String tipoDocumento;
        private final String numeroDocumento;
        private final String nombres;
        private final String apellidos;
        private double dineroRecaudado;

        private Vendedor(String tipoDocumento, String numeroDocumento,
                String nombres, String apellidos) {
            this.tipoDocumento = tipoDocumento;
            this.numeroDocumento = numeroDocumento;
            this.nombres = nombres;
            this.apellidos = apellidos;
        }

        private double getDineroRecaudado() {
            return dineroRecaudado;
        }
    }
}
