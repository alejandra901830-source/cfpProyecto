import java.io.File;
import java.io.IOException;
import java.io.PrintWriter;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

/**
 * Genera archivos de prueba para el sistema de procesamiento de ventas.
 * No solicita datos por teclado: utiliza cantidades y catálogos definidos.
 *
 * @author Equipo de trabajo
 * @version 1.0
 */
public class GenerateInfoFiles {

    private static final String ARCHIVO_PRODUCTOS = "productos.csv";
    private static final String ARCHIVO_VENDEDORES = "vendedores.csv";
    private static final String[] NOMBRES = {
        "Carlos", "Ana", "Luis", "Maria", "Juan", "Laura", "Andres", "Sofia"
    };
    private static final String[] APELLIDOS = {
        "Gomez", "Perez", "Rodriguez", "Martinez", "Lopez", "Garcia"
    };
    private static final String[] TIPOS_DOCUMENTO = {"CC", "CE", "TI"};
    private static final String[] NOMBRES_PRODUCTOS = {
        "Laptop", "Mouse", "Teclado", "Monitor", "Audifonos", "Webcam"
    };
    private static final double[] PRECIOS_PRODUCTOS = {
        2500000.50, 80000.00, 150000.99, 950000.00, 120000.00, 210000.00
    };
    private static final Random RANDOM = new Random();

    /**
     * Punto de entrada. Genera los tres tipos de archivos de entrada.
     *
     * @param args argumentos de consola (no utilizados)
     */
    public static void main(String[] args) {
        try {
            createProductsFile(NOMBRES_PRODUCTOS.length);
            deleteOldSalesFiles();
            createSalesManInfoFile(3);
            System.out.println("Generación de archivos finalizada exitosamente.");
        } catch (Exception exception) {
            System.err.println("ERROR al generar los archivos: " + exception.getMessage());
        }
    }

    /**
     * Crea un catálogo de productos con identificador, nombre y precio.
     *
     * @param productsCount cantidad de productos que se generarán
     * @throws IOException si no se puede escribir el archivo
     * @throws IllegalArgumentException si la cantidad no es válida
     */
    public static void createProductsFile(int productsCount) throws IOException {
        if (productsCount < 1 || productsCount > NOMBRES_PRODUCTOS.length) {
            throw new IllegalArgumentException("La cantidad de productos debe estar entre 1 y "
                    + NOMBRES_PRODUCTOS.length + ".");
        }
        try (PrintWriter writer = new PrintWriter(
                Files.newBufferedWriter(Paths.get(ARCHIVO_PRODUCTOS), StandardCharsets.UTF_8))) {
            for (int index = 0; index < productsCount; index++) {
                writer.println((index + 1) + ";" + NOMBRES_PRODUCTOS[index]
                        + ";" + PRECIOS_PRODUCTOS[index]);
            }
        }
    }

    /**
     * Crea el archivo maestro de vendedores y un archivo de ventas por vendedor.
     *
     * @param salesmanCount cantidad de vendedores que se generarán
     * @throws IOException si no se pueden escribir los archivos
     */
    public static void createSalesManInfoFile(int salesmanCount) throws IOException {
        if (salesmanCount < 1) {
            throw new IllegalArgumentException("Debe generarse al menos un vendedor.");
        }

        List<String> idsUsados = new ArrayList<String>();
        try (PrintWriter writer = new PrintWriter(
                Files.newBufferedWriter(Paths.get(ARCHIVO_VENDEDORES), StandardCharsets.UTF_8))) {
            for (int index = 0; index < salesmanCount; index++) {
                long id;
                do {
                    id = 100000000L + RANDOM.nextInt(900000000);
                } while (idsUsados.contains(String.valueOf(id)));
                idsUsados.add(String.valueOf(id));

                String tipoDocumento = TIPOS_DOCUMENTO[RANDOM.nextInt(TIPOS_DOCUMENTO.length)];
                String nombre = NOMBRES[RANDOM.nextInt(NOMBRES.length)];
                String apellido = APELLIDOS[RANDOM.nextInt(APELLIDOS.length)];

                writer.println(tipoDocumento + ";" + id + ";" + nombre + ";" + apellido);
                createSalesMenFile(RANDOM.nextInt(5) + 2, tipoDocumento, id);
            }
        }
    }

    /**
     * Crea las ventas pseudoaleatorias de un vendedor.
     *
     * @param randomSalesCount cantidad de líneas de venta
     * @param name tipo de documento que identifica al vendedor en el encabezado
     * @param id número de documento del vendedor
     * @throws IOException si no se puede escribir el archivo
     */
    public static void createSalesMenFile(int randomSalesCount, String name, long id)
            throws IOException {
        if (randomSalesCount < 0) {
            throw new IllegalArgumentException("La cantidad de ventas no puede ser negativa.");
        }
        Path filePath = Paths.get("vendedor_" + id + ".csv");
        try (PrintWriter writer = new PrintWriter(
                Files.newBufferedWriter(filePath, StandardCharsets.UTF_8))) {
            writer.println(name + ";" + id);
            for (int index = 0; index < randomSalesCount; index++) {
                int productId = RANDOM.nextInt(NOMBRES_PRODUCTOS.length) + 1;
                int quantity = RANDOM.nextInt(10) + 1;
                writer.println(productId + ";" + quantity + ";");
            }
        }
    }

    /**
     * Elimina los archivos individuales de ventas creados en ejecuciones previas.
     */
    private static void deleteOldSalesFiles() throws IOException {
        File currentDirectory = new File(".");
        File[] files = currentDirectory.listFiles();
        if (files == null) {
            throw new IOException("No fue posible listar la carpeta del proyecto.");
        }
        for (File file : files) {
            String fileName = file.getName();
            if (file.isFile() && fileName.startsWith("vendedor_")
                    && fileName.endsWith(".csv") && !file.delete()) {
                throw new IOException("No se pudo eliminar el archivo anterior: " + fileName);
            }
        }
    }
}
