# Conceptos Fundamentales de Programación - Entrega 2

## Integrantes
- DAVID SANTIAGO RICO MALDONADO
- JEIDY RIVEROS PEREZ
- ANGIE RODRIGUEZ RODRIGUEZ
- SEBASTIAN SILVA CHIVATA

## Repositorio
https://github.com/alejandra901830-source/cfpProyecto

## Entrega 2 - Semana 5

Esta version incorpora el procesamiento principal del proyecto mediante la
clase `main`, manteniendo `GenerateInfoFiles` para generar los archivos de
entrada.

### Clases con método main
- `GenerateInfoFiles`
- `main`

### Archivos de entrada
- `productos.csv`
- `vendedores.csv`
- `vendedor_<id>.csv`

### Reportes
- `reporte_vendedores.csv`: nombres y dinero recaudado, ordenados de mayor a menor.
- `reporte_productos.csv`: nombre y precio de cada producto, ordenados según la
  cantidad total vendida.

## Ejecucion
1. Ejecutar `GenerateInfoFiles`.
2. Ejecutar `main`.

El programa no solicita datos al usuario.
