# Conceptos Fundamentales de Programación — Entrega final

## Integrantes
- DAVID SANTIAGO RICO MALDONADO
- JEIDY RIVEROS PEREZ
- ANGIE RODRIGUEZ RODRIGUEZ
- SEBASTIAN SILVA CHIVATA

## Repositorio
https://github.com/alejandra901830-source/cfpProyecto

## Requisitos
- Java 8.
- Proyecto compatible con Eclipse y Maven.
- No solicita datos por teclado.
- Contiene exactamente dos clases con método `main`: `GenerateInfoFiles` y `main`.

## Archivos de entrada
- `productos.csv`: ID;nombre;precio por unidad.
- `vendedores.csv`: tipo de documento;número de documento;nombres;apellidos.
- `vendedor_<id>.csv`: encabezado tipo de documento;número de documento y una venta por línea (ID de producto;cantidad).

## Ejecución
1. Importar el proyecto en Eclipse como proyecto Maven existente.
2. Ejecutar `GenerateInfoFiles.java` como **Java Application**.
3. Ejecutar `main.java` como **Java Application**.
4. Verificar `reporte_vendedores.csv` y `reporte_productos.csv` en la carpeta raíz del proyecto.

`GenerateInfoFiles` crea los archivos pseudoaleatorios. `main` procesa los archivos de entrada, valida formatos básicos, calcula recaudos y cantidades, ordena los resultados y crea los dos reportes.

## Formato de reportes
- `reporte_vendedores.csv`: nombre completo;dinero recaudado, orden descendente.
- `reporte_productos.csv`: nombre del producto;precio unitario, orden descendente por cantidad vendida.

Los reportes no incluyen una columna de cantidad vendida porque el enunciado solicita únicamente nombre y precio para el reporte de productos.
